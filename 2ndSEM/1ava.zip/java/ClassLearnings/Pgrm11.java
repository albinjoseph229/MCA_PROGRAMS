//static fuction
import java.io.*;
class Pgrm11{
    public static void disp(){
        System.out.println("in disp()");
    }
    public static void main(String[] args) {
        disp();
    }
}
