// Get InetAddress object representing localhost
            // InetAddress localhost = InetAddress.getLocalHost();
            // System.out.println("Localhost IP Address: " + localhost.getHostAddress());
            // System.out.println("Localhost Hostname: " + localhost.getHostName());

            // // Get InetAddress object by IP address
            // InetAddress address = InetAddress.getByName("8.8.8.8");
            // System.out.println("Google DNS IP Address: " + address.getHostAddress());
            // System.out.println("Google DNS Hostname: " + address.getHostName());
